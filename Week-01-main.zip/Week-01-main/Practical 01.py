#Task 1
print("the program has executed")

#Task 2
help()
help(print)

#Task 3
10 + 20 - 15
10 * 5
100 / 33
100 // 33
10 ** 2
10 % 3

#Task 4
10 + 5 * 2
10 - 5 * 10 + 5
5 * 10 ** 2

#Task 5
(10 + 5) * 2
10 - 5 * (10 + 5)
(5 * 10) ** 2

#Task 6
12 + (5 * 2 + 3)
12 + (5 * (2 + 3))

#Task 7
10 +
print("Ten divided by zero is", 10/0 )
